import express from 'express';
import path from 'path';
import apiRouter from './src/server/api.ts';

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());
app.use(apiRouter);

// Serve static frontend build
const distPath = path.resolve(process.cwd(), 'dist');
app.use(express.static(distPath));

// SPA fallback for client-side routing
app.get('*', (_req, res) => {
  res.sendFile(path.resolve(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on http://0.0.0.0:${PORT}`);
});
