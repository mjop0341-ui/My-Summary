import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { getStorage } from 'firebase/storage';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  getDocs,
  collection,
  query,
  where,
  orderBy,
  updateDoc,
  deleteDoc,
  increment,
  getDocFromServer
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firestore with Database ID (MANDATORY per skill)
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Initialize Firebase Storage
export const storage = getStorage(app);

// Initialize Auth
export const auth = getAuth(app);
export const googleAuthProvider = new GoogleAuthProvider();
googleAuthProvider.setCustomParameters({ prompt: 'select_account' });

// Test connection on boot
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

// Error handling conforming to Firebase skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface AuthDomainError extends Error {
  isUnauthorizedDomain?: boolean;
  domain?: string;
  projectId?: string;
}

// Sign-in with Google helper using popup
export async function signInWithGoogle(): Promise<User> {
  try {
    const result = await signInWithPopup(auth, googleAuthProvider);
    const user = result.user;
    
    // Save user profile in Firestore
    const userRef = doc(db, 'users', user.uid);
    await setDoc(userRef, {
      uid: user.uid,
      email: user.email || '',
      displayName: user.displayName || 'مستخدم سحاب',
      photoURL: user.photoURL || '',
      updatedAt: new Date().toISOString()
    }, { merge: true });

    return user;
  } catch (err: any) {
    console.error('Google Sign In Error:', err);
    if (err?.code === 'auth/unauthorized-domain') {
      const customErr: AuthDomainError = new Error(
        `النطاق الحالي (${window.location.hostname}) غير مصرح به في Firebase Console.`
      );
      customErr.isUnauthorizedDomain = true;
      customErr.domain = window.location.hostname;
      customErr.projectId = firebaseConfig.projectId;
      throw customErr;
    }
    throw err;
  }
}

export async function logOut(): Promise<void> {
  await signOut(auth);
  localStorage.removeItem('sahab_demo_user');
}

// Firestore File Record interface
export interface FileMetadata {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  extension: string;
  downloadsCount: number;
  userId: string | null;
  userEmail: string | null;
  userName: string | null;
  createdAt: string;
  isPublic: boolean;
  directUrl: string;
  shareUrl: string;
  previewUrl?: string;
  base64Data?: string;
  storageType?: string;
  chunksCount?: number;
  storageUrl?: string;
}

// Save file metadata to Firestore
export async function saveFileMetadata(meta: FileMetadata) {
  const path = `files/${meta.id}`;
  try {
    const fileRef = doc(db, 'files', meta.id);
    await setDoc(fileRef, {
      id: meta.id,
      name: meta.name,
      size: meta.size,
      mimeType: meta.mimeType,
      extension: meta.extension,
      downloadsCount: meta.downloadsCount || 0,
      userId: meta.userId || null,
      userEmail: meta.userEmail || null,
      userName: meta.userName || null,
      createdAt: meta.createdAt,
      isPublic: true,
      storageType: meta.storageType || 'firestore',
      directUrl: meta.directUrl,
      shareUrl: meta.shareUrl,
      ...(meta.base64Data ? { base64Data: meta.base64Data } : {}),
      ...(meta.chunksCount ? { chunksCount: meta.chunksCount } : {}),
      ...(meta.storageUrl ? { storageUrl: meta.storageUrl } : {}),
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// Increment downloads in Firestore
export async function recordDownloadInFirestore(fileId: string) {
  const path = `files/${fileId}`;
  try {
    const fileRef = doc(db, 'files', fileId);
    await updateDoc(fileRef, {
      downloadsCount: increment(1)
    });
  } catch (error) {
    console.warn('Could not increment Firestore count:', error);
  }
}

// Delete file from Firestore
export async function deleteFileFromFirestore(fileId: string) {
  const path = `files/${fileId}`;
  try {
    await deleteDoc(doc(db, 'files', fileId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
