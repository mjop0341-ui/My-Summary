import React, { useState } from 'react';
import { Cloud, Upload, FolderHeart, LogIn, LogOut, CheckCircle2, ShieldAlert } from 'lucide-react';
import { User } from 'firebase/auth';
import { signInWithGoogle, logOut } from '../lib/firebase.ts';
import { AuthorizedDomainModal } from './AuthorizedDomainModal.tsx';

interface NavbarProps {
  user: User | null;
  activeTab: 'upload' | 'my-files';
  setActiveTab: (tab: 'upload' | 'my-files') => void;
  userFilesCount: number;
  onDemoLogin: (name: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeTab,
  setActiveTab,
  userFilesCount,
  onDemoLogin,
}) => {
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [showDomainModal, setShowDomainModal] = useState(false);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState('');
  const [firebaseProjectId, setFirebaseProjectId] = useState('');

  const handleSignIn = async () => {
    try {
      setIsSigningIn(true);
      setAuthError(null);
      await signInWithGoogle();
    } catch (err: any) {
      console.error('Sign in error:', err);
      if (err?.isUnauthorizedDomain) {
        setUnauthorizedDomain(err.domain || window.location.hostname);
        setFirebaseProjectId(err.projectId || 'gen-lang-client-0896569783');
        setShowDomainModal(true);
        setAuthError(
          `نطاق Vercel الحالي (${window.location.hostname}) يتطلب إضافة إلى Authorized Domains في Firebase.`
        );
      } else {
        setAuthError('تعذر تسجيل الدخول، يرجى المحاولة مرة أخرى أو استخدام الدخول السريع');
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await logOut();
      setActiveTab('upload');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between">
        {/* Brand */}
        <div 
          onClick={() => {
            window.location.hash = '';
            setActiveTab('upload');
          }}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <Cloud className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-2xl tracking-tight text-slate-900 font-sans">
                سحاب
              </span>
              <span className="text-[11px] font-semibold tracking-wide bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full border border-indigo-200/60">
                رابط مباشر فوري
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              رفع ومشاركة كل أنواع الملفات بضغطة واحدة
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => {
              window.location.hash = '';
              setActiveTab('upload');
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'upload'
                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/80 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>رفع ملف</span>
          </button>

          {user && (
            <button
              onClick={() => {
                window.location.hash = '';
                setActiveTab('my-files');
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'my-files'
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/80 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              <FolderHeart className="w-4 h-4" />
              <span>ملفاتي</span>
              {userFilesCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[11px] flex items-center justify-center font-bold">
                  {userFilesCount}
                </span>
              )}
            </button>
          )}

          <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block" />

          {/* User / Sign-In */}
          {user ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2.5 bg-slate-50 border border-slate-200/80 px-2.5 py-1.5 rounded-2xl">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-500/20"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <div className="hidden md:block text-right">
                  <p className="text-xs font-bold text-slate-800 leading-tight">
                    {user.displayName || 'مستخدم'}
                  </p>
                  <p className="text-[10px] text-slate-500 truncate max-w-[120px]">
                    {user.email || 'حساب سحاب'}
                  </p>
                </div>
              </div>

              <button
                onClick={handleSignOut}
                title="تسجيل الخروج"
                className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors border border-transparent hover:border-rose-200 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={handleSignIn}
                disabled={isSigningIn}
                className="flex items-center gap-2.5 px-4 py-2 rounded-xl text-sm font-bold bg-white text-slate-700 hover:bg-slate-50 border border-slate-300 shadow-xs hover:border-slate-400 active:scale-98 transition-all disabled:opacity-50 cursor-pointer"
              >
                {/* Google Icon SVG */}
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>{isSigningIn ? 'جاري الاتصال...' : 'دخول بحساب Google'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {authError && (
        <div className="bg-amber-50 text-amber-900 text-xs py-2 px-4 text-center border-t border-amber-200 flex items-center justify-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{authError}</span>
          <button
            onClick={() => {
              setUnauthorizedDomain(window.location.hostname);
              setFirebaseProjectId('gen-lang-client-0896569783');
              setShowDomainModal(true);
            }}
            className="underline font-bold text-indigo-700 cursor-pointer mr-1"
          >
            حل المشكلة الآن
          </button>
        </div>
      )}

      {/* Authorized Domain Helper Modal */}
      {showDomainModal && (
        <AuthorizedDomainModal
          domain={unauthorizedDomain || window.location.hostname}
          projectId={firebaseProjectId || 'gen-lang-client-0896569783'}
          onClose={() => setShowDomainModal(false)}
          onDemoLogin={onDemoLogin}
        />
      )}
    </header>
  );
};
