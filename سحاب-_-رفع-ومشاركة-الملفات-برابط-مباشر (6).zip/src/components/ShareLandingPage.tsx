import React, { useEffect, useState } from 'react';
import {
  Download,
  Copy,
  CheckCircle,
  FileText,
  FileArchive,
  Film,
  Music,
  FileCode,
  File as FileIcon,
  Image as ImageIcon,
  ArrowRight,
  ShieldCheck,
  Eye,
  QrCode,
  Calendar,
  HardDrive,
  User as UserIcon,
} from 'lucide-react';
import QRCode from 'qrcode';
import { doc, getDoc } from 'firebase/firestore';
import { db, FileMetadata } from '../lib/firebase.ts';
import { formatBytes, formatDate, getFileCategory, getCategoryBadgeColor } from '../lib/utils.ts';
import { downloadFileContent, triggerBlobDownload } from '../lib/cloudStorage.ts';

interface ShareLandingPageProps {
  fileId: string;
  onGoBack: () => void;
  autoDownload?: boolean;
}

export const ShareLandingPage: React.FC<ShareLandingPageProps> = ({
  fileId,
  onGoBack,
  autoDownload = false,
}) => {
  const [file, setFile] = useState<FileMetadata | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copiedDirect, setCopiedDirect] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    let isMounted = true;
    async function fetchFileInfo() {
      setLoading(true);
      setError(null);
      try {
        let meta: FileMetadata | null = null;

        // Try API first
        try {
          const res = await fetch(`/api/files/${fileId}`);
          if (res.ok) {
            meta = await res.json();
          }
        } catch {
          // ignore API error on static hosts
        }

        // If API didn't return, fetch directly from Firestore cloud database!
        if (!meta) {
          const docRef = doc(db, 'files', fileId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const data = docSnap.data();
            const baseUrl = window.location.origin;
            meta = {
              ...(data as any),
              id: fileId,
              directUrl: data.directUrl || `${baseUrl}/d/${fileId}`,
              shareUrl: data.shareUrl || `${baseUrl}/#file=${fileId}`,
              previewUrl: `${baseUrl}/api/preview/${fileId}`,
            };
          }
        }

        if (!meta) {
          throw new Error('الملف غير موجود في قاعدة البيانات أو ربما تم حذفه');
        }

        if (isMounted) {
          setFile(meta);

          // Generate QR code
          try {
            const qr = await QRCode.toDataURL(meta.directUrl, {
              width: 320,
              margin: 2,
              color: { dark: '#1e1b4b', light: '#ffffff' },
            });
            setQrCodeUrl(qr);
          } catch {
            // ignore
          }

          // If autoDownload is requested (e.g. from /d/:id direct link route)
          if (autoDownload) {
            setTimeout(() => {
              triggerFileDownload(meta);
            }, 600);
          }
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err.message || 'فشل تحميل بيانات الملف من السحاب');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    if (fileId) {
      fetchFileInfo();
    }
    return () => {
      isMounted = false;
    };
  }, [fileId, autoDownload]);

  const copyToClipboard = async (text: string, type: 'direct' | 'share') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'direct') {
        setCopiedDirect(true);
        setTimeout(() => setCopiedDirect(false), 2500);
      } else {
        setCopiedShare(true);
        setTimeout(() => setCopiedShare(false), 2500);
      }
    } catch {
      // fallback
    }
  };

  const triggerFileDownload = async (targetFile: FileMetadata) => {
    setIsDownloading(true);
    setDownloadStarted(true);
    try {
      const blob = await downloadFileContent(targetFile);
      triggerBlobDownload(blob, targetFile.name);
      setFile((prev) => (prev ? { ...prev, downloadsCount: (prev.downloadsCount || 0) + 1 } : null));
    } catch (err) {
      console.warn('Direct blob download fallback to URL:', err);
      window.location.href = targetFile.directUrl;
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownload = () => {
    if (!file) return;
    triggerFileDownload(file);
  };

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center">
        <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-center mx-auto mb-4 animate-spin text-indigo-600">
          <Download className="w-6 h-6" />
        </div>
        <p className="font-bold text-slate-700 text-sm">جاري جلب تفاصيل الملف من قاعدة البيانات السحابية...</p>
      </div>
    );
  }

  if (error || !file) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center">
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl p-8">
          <div className="w-16 h-16 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-4">
            <FileIcon className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-black text-slate-900 mb-2">الملف غير متاح</h3>
          <p className="text-xs text-slate-500 mb-6">{error || 'تعذر العثور على هذا الملف'}</p>
          <button
            onClick={onGoBack}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة لصفحة الرفع</span>
          </button>
        </div>
      </div>
    );
  }

  const category = getFileCategory(file.extension, file.mimeType);
  const badgeColors = getCategoryBadgeColor(category);

  return (
    <div className="max-w-3xl mx-auto py-6 sm:py-10 px-4">
      {/* Back button */}
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={onGoBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-indigo-600 bg-white hover:bg-slate-50 border border-slate-200/80 px-3.5 py-2 rounded-xl transition-all shadow-2xs cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع لمركز الرفع</span>
        </button>

        <span className="text-xs text-slate-400 font-mono">
          معرّف الملف: {file.id}
        </span>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-200/50 overflow-hidden">
        {/* Top Header Card */}
        <div className="p-6 sm:p-8 bg-gradient-to-b from-slate-50/80 to-white border-b border-slate-100">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-16 h-16 rounded-2xl bg-white border border-slate-200/90 flex items-center justify-center shrink-0 shadow-xs">
                {category === 'image' && <ImageIcon className="w-9 h-9 text-emerald-600" />}
                {category === 'video' && <Film className="w-9 h-9 text-purple-600" />}
                {category === 'audio' && <Music className="w-9 h-9 text-pink-600" />}
                {category === 'document' && <FileText className="w-9 h-9 text-blue-600" />}
                {category === 'archive' && <FileArchive className="w-9 h-9 text-amber-600" />}
                {category === 'code' && <FileCode className="w-9 h-9 text-cyan-600" />}
                {category === 'other' && <FileIcon className="w-9 h-9 text-indigo-600" />}
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-md border ${badgeColors.bg} ${badgeColors.text} ${badgeColors.border}`}
                  >
                    {file.extension || 'ملف'}
                  </span>
                  <span className="text-xs text-emerald-700 font-medium flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/60">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    تخزين سحابي آمن
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-black text-slate-900 truncate" title={file.name}>
                  {file.name}
                </h2>
              </div>
            </div>

            <div className="text-left shrink-0">
              <p className="text-xs text-slate-400">الحجم الكلي</p>
              <p className="text-lg font-extrabold text-slate-900 font-sans">
                {formatBytes(file.size)}
              </p>
            </div>
          </div>

          {/* Inline Media Preview if base64 or preview url available */}
          {category === 'image' && (file.base64Data || file.storageUrl || file.previewUrl) && (
            <div className="mt-6 rounded-2xl overflow-hidden border border-slate-200 bg-slate-900/5 max-h-96 flex items-center justify-center p-2">
              <img
                src={file.base64Data || file.storageUrl || file.previewUrl}
                alt={file.name}
                className="max-h-96 w-auto object-contain rounded-xl"
              />
            </div>
          )}

          {category === 'audio' && (file.base64Data || file.storageUrl || file.previewUrl) && (
            <div className="mt-6 p-4 rounded-2xl bg-pink-50/50 border border-pink-100">
              <audio controls className="w-full">
                <source src={file.base64Data || file.storageUrl || file.previewUrl} type={file.mimeType} />
                متصفحك لا يدعم تشغيل الصوت مباشرة.
              </audio>
            </div>
          )}
        </div>

        {/* Action Panel */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* PRIMARY DOWNLOAD BUTTON */}
          <div>
            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white font-black text-base shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-3 transition-all cursor-pointer disabled:opacity-50"
            >
              <Download className="w-5 h-5" />
              <span>{isDownloading ? 'جاري بدء التنزيل...' : 'تحميل الملف الآن (رابط مباشر)'}</span>
            </button>
            <p className="text-center text-xs text-slate-500 mt-2">
              يبدأ التنزيل المباشر فوراً على جهازك دون أي صفحات وسيطة أو إعلانات
            </p>
          </div>

          {downloadStarted && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold text-center flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>بدأ تنزيل الملف! إذا لم يبدأ تلقائياً، اضغط على زر التحميل مرة أخرى.</span>
            </div>
          )}

          {/* DIRECT LINK COPY FIELD */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
              <span>رابط التنزيل المباشر الفوري</span>
              <span className="text-[11px] text-indigo-600">ألصقه في أي متصفح ليبدأ التنزيل فوراً</span>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                readOnly
                dir="ltr"
                value={file.directUrl}
                onClick={(e) => (e.target as HTMLInputElement).select()}
                className="w-full bg-white text-slate-800 text-xs font-mono py-2 px-3 rounded-xl border border-slate-300 focus:outline-hidden"
              />
              <button
                onClick={() => copyToClipboard(file.directUrl, 'direct')}
                className={`flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  copiedDirect
                    ? 'bg-emerald-600 text-white'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                }`}
              >
                {copiedDirect ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedDirect ? 'تم النسخ!' : 'نسخ الرابط المباشر'}</span>
              </button>
            </div>
          </div>

          {/* FILE DETAILS GRID */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <HardDrive className="w-3.5 h-3.5 text-slate-400" />
                <span>الحجم</span>
              </div>
              <p className="font-bold text-xs text-slate-800">{formatBytes(file.size)}</p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Eye className="w-3.5 h-3.5 text-slate-400" />
                <span>التحميلات</span>
              </div>
              <p className="font-bold text-xs text-slate-800">{file.downloadsCount || 0} مرة</p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>تاريخ الرفع</span>
              </div>
              <p className="font-bold text-[11px] text-slate-800 truncate">{formatDate(file.createdAt)}</p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                <span>الرافع</span>
              </div>
              <p className="font-bold text-xs text-slate-800 truncate">{file.userName || 'مستخدم سحاب'}</p>
            </div>
          </div>

          {/* QR CODE SECTION */}
          {qrCodeUrl && (
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100">
              <div className="flex items-center gap-3">
                <div className="p-1.5 bg-white rounded-xl border border-indigo-200/80 shadow-2xs shrink-0">
                  <img src={qrCodeUrl} alt="QR Code" className="w-16 h-16 rounded" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-indigo-950 flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-indigo-600" />
                    تحميل فوري عبر الهاتف
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    امسح الرمز بكاميرا هاتفك لبدء التنزيل على الموبايل مباشرة.
                  </p>
                </div>
              </div>

              <button
                onClick={() => copyToClipboard(file.shareUrl, 'share')}
                className="w-full sm:w-auto px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700 shadow-2xs transition-all shrink-0 cursor-pointer"
              >
                {copiedShare ? 'تم نسخ رابط المشاركة' : 'مشاركة هذه الصفحة'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
