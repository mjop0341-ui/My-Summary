import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  File as FileIcon,
  CheckCircle,
  Copy,
  ExternalLink,
  QrCode,
  Sparkles,
  ArrowRight,
  RefreshCw,
  X,
  FileText,
  FileCode,
  FileArchive,
  Film,
  Music,
  Image as ImageIcon,
  Zap,
  ShieldCheck,
  Download,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import QRCode from 'qrcode';
import { User } from 'firebase/auth';
import { FileMetadata } from '../lib/firebase.ts';
import { formatBytes, getFileCategory } from '../lib/utils.ts';
import { uploadUniversal, downloadFileContent, triggerBlobDownload } from '../lib/cloudStorage.ts';

interface UploadZoneProps {
  user: User | null;
  onUploadSuccess: (file: FileMetadata) => void;
  onOpenSharePage: (fileId: string) => void;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  user,
  onUploadSuccess,
  onOpenSharePage,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadedBytes, setUploadedBytes] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState('');
  const [timeRemaining, setTimeRemaining] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [completedFile, setCompletedFile] = useState<FileMetadata | null>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [copiedDirect, setCopiedDirect] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [downloadingDirect, setDownloadingDirect] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const cancelUpload = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setUploading(false);
    setProgress(0);
    setError('تم إلغاء عملية الرفع من قبل المستخدم');
  };

  // File selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      selectFile(e.target.files[0]);
    }
  };

  const selectFile = (file: File) => {
    if (file.size > 50 * 1024 * 1024) {
      setError(`حجم الملف (${formatBytes(file.size)}) أكبر من الحد الأقصى (40-50 ميجابايت). يرجى اختيار ملف بحجم 40 ميجابايت أو أقل.`);
      setSelectedFile(null);
      return;
    }
    setSelectedFile(file);
    setError(null);
    setCompletedFile(null);
    setProgress(0);
  };

  // Drag handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      selectFile(e.dataTransfer.files[0]);
    }
  };

  // Universal upload handler that works 100% on Vercel & everywhere
  const startUpload = async () => {
    if (!selectedFile) return;

    const controller = new AbortController();
    abortControllerRef.current = controller;

    setUploading(true);
    setProgress(5);
    setError(null);

    try {
      const meta = await uploadUniversal(
        selectedFile,
        user ? user.uid : null,
        user ? user.email : null,
        user ? user.displayName : null,
        (percent, loaded, _total, speed, remaining) => {
          setProgress(percent);
          setUploadedBytes(loaded);
          setUploadSpeed(speed);
          setTimeRemaining(remaining);
        },
        controller.signal
      );

      setCompletedFile(meta);
      onUploadSuccess(meta);

      // Generate QR Code
      try {
        const qr = await QRCode.toDataURL(meta.directUrl, {
          width: 320,
          margin: 2,
          color: { dark: '#1e1b4b', light: '#ffffff' },
        });
        setQrCodeUrl(qr);
      } catch (qrErr) {
        console.warn('QR generation error:', qrErr);
      }

      // Celebration confetti
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#4f46e5', '#38bdf8', '#10b981', '#f59e0b'],
      });
    } catch (err: any) {
      if (err?.message?.includes('تم إلغاء')) {
        setError('تم إلغاء عملية الرفع.');
      } else {
        console.error('Upload failed:', err);
        setError(err?.message || 'فشل رفع الملف، يرجى التحقق من الاتصال والمحاولة ثانية');
      }
    } finally {
      setUploading(false);
    }
  };

  const handleDirectDownloadTest = async () => {
    if (!completedFile) return;
    setDownloadingDirect(true);
    try {
      const blob = await downloadFileContent(completedFile);
      triggerBlobDownload(blob, completedFile.name);
    } catch {
      window.location.href = completedFile.directUrl;
    } finally {
      setDownloadingDirect(false);
    }
  };

  const copyToClipboard = async (text: string, type: 'direct' | 'share') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'direct') {
        setCopiedDirect(true);
        setTimeout(() => setCopiedDirect(false), 2500);
      } else {
        setCopiedShare(true);
        setTimeout(() => setCopiedShare(false), 2500);
      }
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      if (type === 'direct') {
        setCopiedDirect(true);
        setTimeout(() => setCopiedDirect(false), 2500);
      } else {
        setCopiedShare(true);
        setTimeout(() => setCopiedShare(false), 2500);
      }
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setCompletedFile(null);
    setProgress(0);
    setError(null);
    setQrCodeUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const renderFileIcon = (filename: string) => {
    const ext = filename.split('.').pop() || '';
    const cat = getFileCategory(ext);
    switch (cat) {
      case 'image':
        return <ImageIcon className="w-9 h-9 text-emerald-600" />;
      case 'video':
        return <Film className="w-9 h-9 text-purple-600" />;
      case 'audio':
        return <Music className="w-9 h-9 text-pink-600" />;
      case 'archive':
        return <FileArchive className="w-9 h-9 text-amber-600" />;
      case 'code':
        return <FileCode className="w-9 h-9 text-cyan-600" />;
      case 'document':
        return <FileText className="w-9 h-9 text-blue-600" />;
      default:
        return <FileIcon className="w-9 h-9 text-indigo-600" />;
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* SUCCESS STATE */}
      {completedFile ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-200/50 p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-300">
          <div className="flex items-center justify-between pb-6 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200/60 flex items-center justify-center text-emerald-600 shadow-xs">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900">
                  تم رفع الملف بنجاح!
                </h3>
                <p className="text-xs text-slate-500">
                  تم حفظ الملف في السحاب وتوليد رابط التنزيل المباشر فوراً
                </p>
              </div>
            </div>

            <button
              onClick={resetForm}
              className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100/80 px-3.5 py-2 rounded-xl transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>رفع ملف آخر</span>
            </button>
          </div>

          {/* File Card Info */}
          <div className="my-6 p-4 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-2xs">
                {renderFileIcon(completedFile.name)}
              </div>
              <div className="min-w-0">
                <p className="font-bold text-slate-800 text-sm truncate" title={completedFile.name}>
                  {completedFile.name}
                </p>
                <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700">{formatBytes(completedFile.size)}</span>
                  <span>•</span>
                  <span className="uppercase font-bold text-[10px] bg-slate-200/70 text-slate-700 px-1.5 py-0.5 rounded">
                    {completedFile.extension}
                  </span>
                  <span>•</span>
                  <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/60">
                    سحابي دائم
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowQrModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-xs font-bold text-slate-700 shrink-0 shadow-2xs transition-all cursor-pointer"
              title="عرض رمز QR للهاتف"
            >
              <QrCode className="w-4 h-4 text-indigo-600" />
              <span className="hidden sm:inline">رمز QR</span>
            </button>
          </div>

          {/* PRIMARY: DIRECT DOWNLOAD LINK (رابط التنزيل المباشر) */}
          <div className="mb-6 p-5 rounded-2xl bg-gradient-to-br from-indigo-50/90 to-sky-50/60 border border-indigo-200 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="font-black text-sm text-indigo-950 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-indigo-600 fill-indigo-500" />
                  رابط التنزيل المباشر (Direct Download Link)
                </span>
              </div>
              <span className="text-[11px] font-bold text-indigo-700 bg-white/90 border border-indigo-200/80 px-2.5 py-0.5 rounded-full">
                يبدأ التنزيل فوراً في أي متصفح
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-3 leading-relaxed">
              هذا هو الرابط المباشر للملف! عند لصقه في أي متصفح أو إرساله لصديق يبدأ التحميل مباشرة وفوراً بدون أي صفحات انتظار أو إعلانات.
            </p>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  readOnly
                  dir="ltr"
                  value={completedFile.directUrl}
                  onClick={(e) => (e.target as HTMLInputElement).select()}
                  className="w-full bg-white text-slate-800 text-xs font-mono py-2.5 px-3.5 pr-10 rounded-xl border border-indigo-200/90 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30 selection:bg-indigo-100"
                />
              </div>

              <button
                onClick={() => copyToClipboard(completedFile.directUrl, 'direct')}
                className={`flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-extrabold transition-all shadow-xs cursor-pointer ${
                  copiedDirect
                    ? 'bg-emerald-600 text-white shadow-emerald-500/20'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white active:scale-98 shadow-indigo-500/25'
                }`}
              >
                {copiedDirect ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span>تم النسخ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>نسخ الرابط المباشر</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDirectDownloadTest}
                disabled={downloadingDirect}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-all shrink-0 cursor-pointer disabled:opacity-50"
                title="اختبر الرابط المباشر الآن في متصفحك"
              >
                <Download className="w-3.5 h-3.5 text-indigo-600" />
                <span>{downloadingDirect ? 'جاري التحميل...' : 'تجربة التنزيل الآن'}</span>
              </button>
            </div>
          </div>

          {/* SECONDARY: SHARE LANDING PAGE LINK (رابط المشاركة) */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200">
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <span className="font-bold text-xs text-slate-800">
                رابط صفحة المشاركة والمعاينة (Share Link)
              </span>
              <span className="text-[11px] text-slate-500">
                صفحة أنيقة للمعاينة مع زر تنزيل ورمز QR
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                readOnly
                dir="ltr"
                value={completedFile.shareUrl}
                onClick={(e) => (e.target as HTMLInputElement).select()}
                className="w-full bg-slate-50 text-slate-700 text-xs font-mono py-2 px-3 rounded-xl border border-slate-200 focus:outline-hidden"
              />

              <button
                onClick={() => copyToClipboard(completedFile.shareUrl, 'share')}
                className={`flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  copiedShare
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                }`}
              >
                {copiedShare ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ الرابط</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onOpenSharePage(completedFile.id)}
                className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-indigo-600 hover:bg-indigo-50 border border-indigo-200/80 transition-all shrink-0 cursor-pointer"
              >
                <span>معاينة الصفحة</span>
                <ArrowRight className="w-3 h-3 rotate-180" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* UPLOAD DROPZONE STATE */
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-200/40 p-6 sm:p-9 relative">
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileChange}
            className="hidden"
            disabled={uploading}
          />

          {!selectedFile ? (
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-8 sm:p-14 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center group ${
                dragActive
                  ? 'border-indigo-600 bg-indigo-50/70 scale-[1.01]'
                  : 'border-slate-300 hover:border-indigo-500 bg-slate-50/50 hover:bg-indigo-50/20'
              }`}
            >
              <div className="w-20 h-20 rounded-3xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 mb-5 shadow-sm group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300">
                <UploadCloud className="w-10 h-10" />
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-slate-800 mb-2">
                اسحب وأفلت أي ملف هنا، أو{' '}
                <span className="text-indigo-600 underline underline-offset-4 decoration-indigo-300">
                  تصفح جهازك
                </span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mb-6 leading-relaxed">
                يدعم رفع كافة أنواع الملفات (صور، فيديو، صوت، مستندات، أرشيفات مضغوطة، برامج) حتى 40 ميجابايت للمرة الواحدة بدون أي مشاكل
              </p>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-3 py-1 rounded-full shadow-2xs">
                  🚀 يدعم حتى 40 ميجابايت
                </span>
                <span className="text-[11px] font-bold text-slate-600 bg-white border border-slate-200 px-3 py-1 rounded-full shadow-2xs">
                  ⚡ رابط مباشر فوري
                </span>
                <span className="text-[11px] font-bold text-slate-600 bg-white border border-slate-200 px-3 py-1 rounded-full shadow-2xs">
                  🔗 رابط مشاركة أنيق
                </span>
                <span className="text-[11px] font-bold text-slate-600 bg-white border border-slate-200 px-3 py-1 rounded-full shadow-2xs">
                  ☁️ متوافق 100% مع Vercel
                </span>
              </div>
            </div>
          ) : (
            /* SELECTED FILE PREVIEW & UPLOAD PROGRESS */
            <div>
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/90 mb-6 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-13 h-13 rounded-2xl bg-white border border-slate-200/80 flex items-center justify-center shrink-0 shadow-2xs">
                    {renderFileIcon(selectedFile.name)}
                  </div>
                  <div className="min-w-0">
                    <p className="font-extrabold text-slate-900 text-sm sm:text-base truncate" title={selectedFile.name}>
                      {selectedFile.name}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
                      <span className="font-bold text-slate-700">{formatBytes(selectedFile.size)}</span>
                      <span>•</span>
                      <span className="uppercase font-bold text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full border border-indigo-200/50">
                        {selectedFile.name.split('.').pop() || 'ملف'}
                      </span>
                    </div>
                  </div>
                </div>

                {!uploading && (
                  <button
                    onClick={resetForm}
                    className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-xl transition-colors cursor-pointer"
                    title="إلغاء واختيار ملف آخر"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>

              {/* PROGRESS BAR DISPLAY */}
              {uploading && (
                <div className="mb-6 p-5 rounded-2xl bg-indigo-50/60 border border-indigo-100">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                    <span className="flex items-center gap-1.5 text-indigo-900">
                      <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
                      جاري حفظ ورفع الملف إلى السحاب...
                    </span>
                    <span className="font-mono text-indigo-700 font-extrabold text-sm">{progress}%</span>
                  </div>

                  {/* Visual Bar */}
                  <div className="w-full h-3 bg-slate-200/80 rounded-full overflow-hidden p-0.5 shadow-inner">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 via-indigo-600 to-sky-400 rounded-full transition-all duration-150 ease-out shadow-xs"
                      style={{ width: `${progress}%` }}
                    />
                  </div>

                  {/* Metrics */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mt-3 text-xs text-slate-500 font-medium">
                    <div className="flex items-center gap-3">
                      <span>{formatBytes(uploadedBytes)} من {formatBytes(selectedFile.size)}</span>
                      {uploadSpeed && (
                        <span className="bg-white/80 px-2 py-0.5 rounded-md border border-indigo-100 text-indigo-700 font-bold">
                          {uploadSpeed}
                        </span>
                      )}
                    </div>
                    {timeRemaining && (
                      <span className="text-slate-600">المتبقي: {timeRemaining}</span>
                    )}
                  </div>
                </div>
              )}

              {/* VERCEL 4.5MB LIMIT WARNING */}
              {typeof window !== 'undefined' &&
                window.location.hostname.includes('vercel.app') &&
                selectedFile.size > 4.5 * 1024 * 1024 && (
                  <div className="mb-4 p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs leading-relaxed">
                    <p className="font-bold flex items-center gap-1.5 mb-1 text-amber-800">
                      <span>⚠️ تنبيه استضافة Vercel:</span>
                    </p>
                    <p>
                      منصة Vercel تفرض حداً أقصى صارماً قدره <strong>4.5 ميجابايت</strong> على الطلبات، وترفض الملفات الأكبر حجماً بخطأ <strong>(413 Payload Too Large)</strong>.
                      الملف الحالي حجمه <strong>{formatBytes(selectedFile.size)}</strong>.
                    </p>
                  </div>
                )}

              {/* ACTION BUTTONS */}
              <div className="flex items-center gap-3">
                {!uploading ? (
                  <>
                    <button
                      onClick={startUpload}
                      className="flex-1 flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl font-black text-sm text-white bg-indigo-600 hover:bg-indigo-700 active:scale-98 shadow-lg shadow-indigo-600/25 transition-all cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>بدء الرفع وتوليد الرابط المباشر</span>
                    </button>
                    <button
                      onClick={resetForm}
                      className="py-3.5 px-5 rounded-2xl font-bold text-sm text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 transition-all cursor-pointer"
                    >
                      تغيير الملف
                    </button>
                  </>
                ) : (
                  <button
                    onClick={cancelUpload}
                    className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl font-bold text-sm text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-all cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                    <span>إلغاء عملية الرفع</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {error && (
            <div className="mt-5 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
              <div className="font-extrabold text-sm mb-1 text-rose-900 flex items-center gap-2">
                <span>⚠️</span>
                <span>{error.includes('413') ? 'سبب خطأ SERVER_ERROR_413 والحل المباشر:' : 'فشل عملية الرفع:'}</span>
              </div>
              <p className="leading-relaxed mb-2">{error}</p>

              {error.includes('413') && (
                <div className="mt-3 pt-3 border-t border-rose-200/80 text-[11px] text-slate-700 space-y-1.5">
                  <p className="font-bold text-slate-900">📌 كيف تتخلص من هذا القيد وترفع ملفات حتى 40 ميجابايت؟</p>
                  <p>
                    1. <strong>استضافة Render.com المجانية:</strong> اربط مستودع GitHub الخاص بك على منصة Render.com كـ <strong>Web Service</strong> وسيعمل خادم Node.js المرفق فوراً بدون أي قيود 4.5MB مع دعم حتى 1000 ميجابايت.
                  </p>
                  <p>
                    2. <strong>التشغيل المحلي:</strong> شغّل الأمر <code className="bg-white px-1.5 py-0.5 rounded border border-rose-300 font-mono">npm start</code> لرفع أي ملف بأي حجم بسرعة فائقة.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Quick Features Row */}
          <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            <div className="p-3 rounded-2xl bg-slate-50/60 border border-slate-100">
              <Zap className="w-5 h-5 text-indigo-600 mx-auto mb-1" />
              <p className="font-bold text-xs text-slate-800">رابط مباشر 100%</p>
              <p className="text-[11px] text-slate-500">التنزيل يبدأ تلقائياً وبسرعة فائقة</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50/60 border border-slate-100">
              <ShieldCheck className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
              <p className="font-bold text-xs text-slate-800">سحابي وموثوق</p>
              <p className="text-[11px] text-slate-500">تخزين سحابي محمي بقاعدة البيانات</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50/60 border border-slate-100">
              <QrCode className="w-5 h-5 text-purple-600 mx-auto mb-1" />
              <p className="font-bold text-xs text-slate-800">مشاركة ذكية</p>
              <p className="text-[11px] text-slate-500">رمز QR للمسح من كاميرا الهاتف</p>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Modal */}
      {showQrModal && qrCodeUrl && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h4 className="font-extrabold text-slate-900 text-sm">
                امسح الرمز للتنزيل المباشر
              </h4>
              <button
                onClick={() => setShowQrModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 inline-block mb-3">
              <img src={qrCodeUrl} alt="QR Code" className="w-56 h-56 mx-auto rounded-lg" />
            </div>

            <p className="text-xs text-slate-500 mb-4 leading-relaxed">
              افتح كاميرا هاتفك وامسح الرمز لبدء تحميل الملف فوراً على هاتفك.
            </p>

            <button
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
