import React, { useState } from 'react';
import { ExternalLink, Copy, CheckCircle, AlertTriangle, X, Shield, Sparkles } from 'lucide-react';

interface AuthorizedDomainModalProps {
  domain: string;
  projectId: string;
  onClose: () => void;
  onDemoLogin: (name: string) => void;
}

export const AuthorizedDomainModal: React.FC<AuthorizedDomainModalProps> = ({
  domain,
  projectId,
  onClose,
  onDemoLogin,
}) => {
  const [copied, setCopied] = useState(false);
  const [demoName, setDemoName] = useState('');

  const consoleUrl = `https://console.firebase.google.com/project/${projectId}/authentication/settings`;

  const copyDomain = async () => {
    try {
      await navigator.clipboard.writeText(domain);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleDemoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (demoName.trim()) {
      onDemoLogin(demoName.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base">
                تصريح نطاق Vercel في Firebase
              </h3>
              <p className="text-xs text-slate-500">
                خطوة أمان مطلوبة لمرة واحدة لتفعيل تسجيل الدخول
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-4">
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            عند رفع الموقع على Vercel، تطلب Google إضافة نطاق موقعك الحالي إلى قائمة <strong>النطاقات المصرح بها (Authorized Domains)</strong> لحماية حسابك:
          </p>

          {/* Current Domain Box */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-3">
            <span className="font-mono text-xs font-bold text-slate-800 truncate" dir="ltr">
              {domain}
            </span>
            <button
              onClick={copyDomain}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white'
              }`}
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ النطاق'}</span>
            </button>
          </div>

          {/* Steps */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-2 text-xs text-slate-700">
            <p className="font-bold text-indigo-950">طريقة التفعيل في ثوانٍ معدودة:</p>
            <ol className="list-decimal list-inside space-y-1.5 leading-relaxed text-slate-600">
              <li>
                اضغط على الزر بالأسفل لفتح{' '}
                <a
                  href={consoleUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-indigo-600 font-bold underline inline-flex items-center gap-1"
                >
                  إعدادات مصادقة Firebase <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>انتقل لتبويب <strong>النطاقات المصرح بها (Authorized Domains)</strong>.</li>
              <li>اضغط <strong>إضافة نطاق (Add domain)</strong> والصق: <code className="bg-white px-1 py-0.5 rounded text-[11px] font-mono">{domain}</code></li>
              <li>اضغط <strong>حفظ (Save)</strong>، وسيعمل تسجيل الدخول بـ Google فوراً!</li>
            </ol>
          </div>

          <a
            href={consoleUrl}
            target="_blank"
            rel="noreferrer"
            className="w-full py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/20 transition-all"
          >
            <ExternalLink className="w-4 h-4" />
            <span>فتح إعدادات Firebase وتصريح النطاق</span>
          </a>

          <div className="relative flex py-1 items-center">
            <div className="grow border-t border-slate-200"></div>
            <span className="shrink mx-3 text-slate-400 text-[11px] font-bold">أو المتابعة الآن مباشرة</span>
            <div className="grow border-t border-slate-200"></div>
          </div>

          {/* Quick Demo Login Option */}
          <form onSubmit={handleDemoSubmit} className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-2.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <p className="font-bold text-xs text-slate-800">
                دخول فوري بحساب تجريبي (لحين تصريح النطاق)
              </p>
            </div>
            <p className="text-[11px] text-slate-500">
              يمكنك كتابة اسمك الآن للدخول مباشرة وتجربة حفظ الملفات في قاعدة بيانات Firestore:
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="اكتب اسمك (مثال: محمد)..."
                value={demoName}
                onChange={(e) => setDemoName(e.target.value)}
                className="flex-1 py-2 px-3 rounded-xl bg-white border border-slate-300 text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
              />
              <button
                type="submit"
                disabled={!demoName.trim()}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold transition-all shrink-0"
              >
                دخول فوري
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
