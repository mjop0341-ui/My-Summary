import React, { useState } from 'react';
import {
  File as FileIcon,
  Copy,
  Download,
  Trash2,
  Search,
  CheckCircle,
  ExternalLink,
  HardDrive,
  Eye,
  FileText,
  FileArchive,
  Film,
  Music,
  FileCode,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { FileMetadata, deleteFileFromFirestore } from '../lib/firebase.ts';
import { formatBytes, formatDate, getFileCategory, getCategoryBadgeColor } from '../lib/utils.ts';

interface MyFilesProps {
  user: User | null;
  files: FileMetadata[];
  onFileDeleted: (fileId: string) => void;
  onGoToUpload: () => void;
  onOpenSharePage: (fileId: string) => void;
}

export const MyFiles: React.FC<MyFilesProps> = ({
  user,
  files,
  onFileDeleted,
  onGoToUpload,
  onOpenSharePage,
}) => {
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Filter files
  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(search.toLowerCase()) ||
    f.extension.toLowerCase().includes(search.toLowerCase())
  );

  // Stats
  const totalDownloads = files.reduce((acc, f) => acc + (f.downloadsCount || 0), 0);
  const totalSize = files.reduce((acc, f) => acc + f.size, 0);

  const copyDirectLink = async (file: FileMetadata) => {
    try {
      await navigator.clipboard.writeText(file.directUrl);
      setCopiedId(file.id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      // fallback
    }
  };

  const handleDelete = async (fileId: string) => {
    if (!window.confirm('هل أنت متأكد من رغبتك في حذف هذا الملف نهائياً؟')) {
      return;
    }
    setDeletingId(fileId);
    try {
      // Delete on server
      await fetch(`/api/files/${fileId}`, { method: 'DELETE' });
      // Delete on Firestore
      try {
        await deleteFileFromFirestore(fileId);
      } catch (err) {
        console.warn('Firestore delete note:', err);
      }
      onFileDeleted(fileId);
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setDeletingId(null);
    }
  };

  const renderIcon = (extension: string, mimeType = '') => {
    const cat = getFileCategory(extension, mimeType);
    switch (cat) {
      case 'image':
        return <ImageIcon className="w-5 h-5 text-emerald-600" />;
      case 'video':
        return <Film className="w-5 h-5 text-purple-600" />;
      case 'audio':
        return <Music className="w-5 h-5 text-pink-600" />;
      case 'document':
        return <FileText className="w-5 h-5 text-blue-600" />;
      case 'archive':
        return <FileArchive className="w-5 h-5 text-amber-600" />;
      case 'code':
        return <FileCode className="w-5 h-5 text-cyan-600" />;
      default:
        return <FileIcon className="w-5 h-5 text-indigo-600" />;
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* User Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
            <FileIcon className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">إجمالي الملفات</p>
            <p className="text-2xl font-black text-slate-900 font-sans">{files.length}</p>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
            <Eye className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">مرات التنزيل</p>
            <p className="text-2xl font-black text-slate-900 font-sans">{totalDownloads}</p>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 shrink-0">
            <HardDrive className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">المساحة المستهلكة</p>
            <p className="text-2xl font-black text-slate-900 font-sans">{formatBytes(totalSize)}</p>
          </div>
        </div>
      </div>

      {/* Main Files Table Card */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-200/50 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <h3 className="text-xl font-black text-slate-900">
              ملفاتي المرفوعة
            </h3>
            <p className="text-xs text-slate-500">
              قائمة بجميع الملفات التي قمت برفعها مع الروابط المباشرة وإحصائيات التنزيل
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Search */}
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="ابحث بالاسم أو الصيغة..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-3 pr-9 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            <button
              onClick={onGoToUpload}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shrink-0 shadow-xs transition-all"
            >
              <Upload className="w-4 h-4" />
              <span>رفع جديد</span>
            </button>
          </div>
        </div>

        {/* Files List */}
        {filteredFiles.length === 0 ? (
          <div className="py-16 text-center">
            <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <FileIcon className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-700 text-sm mb-1">
              {search ? 'لا توجد ملفات تطابق البحث' : 'لم تقم برفع أي ملفات بعد'}
            </h4>
            <p className="text-xs text-slate-400 mb-5">
              ارفع أول ملف لك الآن واحصل على رابط مباشر يبدأ التنزيل فوراً!
            </p>
            <button
              onClick={onGoToUpload}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all"
            >
              ابدأ الرفع الآن
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 mt-2">
            {filteredFiles.map((file) => {
              const cat = getFileCategory(file.extension, file.mimeType);
              const badgeColors = getCategoryBadgeColor(cat);
              const isCopied = copiedId === file.id;

              return (
                <div
                  key={file.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group hover:bg-slate-50/70 px-3 -mx-3 rounded-2xl transition-colors"
                >
                  {/* File Info */}
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className="w-11 h-11 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
                      {renderIcon(file.extension, file.mimeType)}
                    </div>
                    <div className="min-w-0">
                      <p
                        className="font-bold text-slate-800 text-sm truncate cursor-pointer hover:text-indigo-600"
                        title={file.name}
                        onClick={() => onOpenSharePage(file.id)}
                      >
                        {file.name}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                        <span className="font-semibold text-slate-600">{formatBytes(file.size)}</span>
                        <span>•</span>
                        <span
                          className={`text-[10px] uppercase font-bold px-1.5 py-0.2 rounded border ${badgeColors.bg} ${badgeColors.text} ${badgeColors.border}`}
                        >
                          {file.extension}
                        </span>
                        <span>•</span>
                        <span>{formatDate(file.createdAt)}</span>
                        <span>•</span>
                        <span className="text-indigo-600 font-bold">{file.downloadsCount || 0} تنزيل</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {/* Copy Direct Link Button */}
                    <button
                      onClick={() => copyDirectLink(file)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        isCopied
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/70'
                      }`}
                      title="نسخ رابط التنزيل المباشر"
                    >
                      {isCopied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isCopied ? 'تم النسخ!' : 'رابط مباشر'}</span>
                    </button>

                    {/* Test Direct Download */}
                    <a
                      href={file.directUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-xl transition-colors"
                      title="تنزيل مباشر للملف"
                    >
                      <Download className="w-4 h-4" />
                    </a>

                    {/* Preview Page */}
                    <button
                      onClick={() => onOpenSharePage(file.id)}
                      className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-xl transition-colors"
                      title="فتح صفحة المشاركة"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => handleDelete(file.id)}
                      disabled={deletingId === file.id}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors disabled:opacity-50"
                      title="حذف الملف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
