import React, { useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, where, getDocs, doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, testConnection, FileMetadata } from './lib/firebase.ts';
import { Navbar } from './components/Navbar.tsx';
import { UploadZone } from './components/UploadZone.tsx';
import { MyFiles } from './components/MyFiles.tsx';
import { ShareLandingPage } from './components/ShareLandingPage.tsx';
import {
  Cloud,
  Zap,
  ShieldCheck,
  Smartphone,
  Globe2,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'my-files'>('upload');
  const [viewingFileId, setViewingFileId] = useState<string | null>(null);
  const [autoDownload, setAutoDownload] = useState(false);
  const [userFiles, setUserFiles] = useState<FileMetadata[]>([]);

  // Parse URL hash for #file=id or pathname /d/id
  const checkRoutes = () => {
    // 1. Direct download path: /d/:fileId -> Trigger direct binary download stream immediately with ZERO web pages
    const pathname = window.location.pathname;
    if (pathname.startsWith('/d/')) {
      const fileId = pathname.replace('/d/', '').split('/')[0];
      if (fileId) {
        window.location.replace(`/api/download/${fileId}`);
        return;
      }
    }

    // 2. Hash routing: #file=:id
    const hash = window.location.hash;
    if (hash.startsWith('#file=')) {
      const fileId = hash.replace('#file=', '').split('&')[0];
      const isDirect = hash.includes('download=direct');
      if (fileId) {
        setViewingFileId(fileId);
        setAutoDownload(isDirect);
        return;
      }
    }

    setViewingFileId(null);
    setAutoDownload(false);
  };

  useEffect(() => {
    testConnection();
    checkRoutes();

    window.addEventListener('hashchange', checkRoutes);
    window.addEventListener('popstate', checkRoutes);

    // Check for stored demo user
    const savedDemo = localStorage.getItem('sahab_demo_user');
    if (savedDemo) {
      try {
        const parsed = JSON.parse(savedDemo);
        setUser(parsed);
        loadUserFiles(parsed.uid);
      } catch {
        // ignore
      }
    }

    // Auth state listener for Firebase
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        localStorage.removeItem('sahab_demo_user');
        loadUserFiles(currentUser.uid);
      } else if (!localStorage.getItem('sahab_demo_user')) {
        setUser(null);
        loadGuestFiles();
      }
    });

    return () => {
      unsubscribe();
      window.removeEventListener('hashchange', checkRoutes);
      window.removeEventListener('popstate', checkRoutes);
    };
  }, []);

  // Fetch files for user: queries Firestore directly (guaranteed to work on Vercel)
  const loadUserFiles = async (uid: string) => {
    try {
      const filesMap = new Map<string, FileMetadata>();

      // 1. Fetch from cached localStorage
      try {
        const cached: FileMetadata[] = JSON.parse(localStorage.getItem('sahab_cached_files') || '[]');
        cached.forEach((f) => {
          if (!f.userId || f.userId === uid || f.userId === 'guest') {
            filesMap.set(f.id, f);
          }
        });
      } catch {
        // ignore
      }

      // 2. Fetch from Firestore directly
      try {
        const q = query(collection(db, 'files'), where('userId', '==', uid));
        const snap = await getDocs(q);
        snap.forEach((d) => {
          const data = d.data() as FileMetadata;
          const baseUrl = window.location.origin;
          filesMap.set(d.id, {
            ...data,
            id: d.id,
            directUrl: data.directUrl || `${baseUrl}/d/${d.id}`,
            shareUrl: data.shareUrl || `${baseUrl}/#file=${d.id}`,
          });
        });
      } catch (fsErr) {
        console.warn('Firestore query note:', fsErr);
      }

      // 3. Try server API if available
      try {
        const res = await fetch(`/api/files?userId=${uid}`);
        if (res.ok) {
          const apiFiles: FileMetadata[] = await res.json();
          apiFiles.forEach((f) => filesMap.set(f.id, f));
        }
      } catch {
        // ignore
      }

      const list = Array.from(filesMap.values());
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setUserFiles(list);
    } catch (err) {
      console.warn('Could not load user files:', err);
    }
  };

  // Load guest files from local session & Firestore
  const loadGuestFiles = async () => {
    try {
      const filesMap = new Map<string, FileMetadata>();

      // 1. Cached files in localStorage
      try {
        const cached: FileMetadata[] = JSON.parse(localStorage.getItem('sahab_cached_files') || '[]');
        cached.forEach((f) => filesMap.set(f.id, f));
      } catch {
        // ignore
      }

      // 2. Query server API if available
      try {
        const res = await fetch('/api/files');
        if (res.ok) {
          const apiFiles: FileMetadata[] = await res.json();
          apiFiles.forEach((f) => filesMap.set(f.id, f));
        }
      } catch {
        // ignore
      }

      // 3. Query Firestore for guest files
      const localIds: string[] = JSON.parse(localStorage.getItem('sahab_guest_files') || '[]');
      if (localIds.length > 0) {
        for (const id of localIds.slice(0, 30)) {
          try {
            const dSnap = await getDoc(doc(db, 'files', id));
            if (dSnap.exists()) {
              const data = dSnap.data() as FileMetadata;
              const baseUrl = window.location.origin;
              filesMap.set(id, {
                ...data,
                id,
                directUrl: data.directUrl || `${baseUrl}/d/${id}`,
                shareUrl: data.shareUrl || `${baseUrl}/#file=${id}`,
              });
            }
          } catch {
            // ignore
          }
        }
      }

      const list = Array.from(filesMap.values());
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setUserFiles(list);
    } catch {
      // ignore
    }
  };

  const handleDemoLogin = async (name: string) => {
    const demoUid = `demo_${Date.now()}`;
    const demoUserObj = {
      uid: demoUid,
      displayName: name,
      email: `${name.toLowerCase().replace(/\s+/g, '_')}@sahab.cloud`,
      photoURL: '',
    } as any;

    setUser(demoUserObj);
    localStorage.setItem('sahab_demo_user', JSON.stringify(demoUserObj));

    // Save in Firestore
    try {
      await setDoc(doc(db, 'users', demoUid), {
        uid: demoUid,
        displayName: name,
        email: demoUserObj.email,
        createdAt: new Date().toISOString(),
      }, { merge: true });
    } catch (e) {
      console.warn('Could not save demo user to Firestore:', e);
    }

    loadUserFiles(demoUid);
  };

  // Called when a file is successfully uploaded
  const handleUploadSuccess = (file: FileMetadata) => {
    setUserFiles((prev) => [file, ...prev.filter((f) => f.id !== file.id)]);

    // Save to guest storage if not logged in
    if (!user) {
      try {
        const current = JSON.parse(localStorage.getItem('sahab_guest_files') || '[]');
        localStorage.setItem('sahab_guest_files', JSON.stringify([file.id, ...current.filter((id: string) => id !== file.id)]));
      } catch {
        // ignore
      }
    }
  };

  const handleFileDeleted = (fileId: string) => {
    setUserFiles((prev) => prev.filter((f) => f.id !== fileId));
    try {
      const current = JSON.parse(localStorage.getItem('sahab_guest_files') || '[]');
      localStorage.setItem('sahab_guest_files', JSON.stringify(current.filter((id: string) => id !== fileId)));
    } catch {
      // ignore
    }
  };

  const openSharePage = (fileId: string) => {
    window.location.hash = `#file=${fileId}`;
    setViewingFileId(fileId);
    setAutoDownload(false);
  };

  const closeSharePage = () => {
    window.location.hash = '';
    window.history.pushState({}, '', '/');
    setViewingFileId(null);
    setAutoDownload(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      {/* Navbar */}
      <Navbar
        user={user}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          closeSharePage();
          setActiveTab(tab);
        }}
        userFilesCount={userFiles.length}
        onDemoLogin={handleDemoLogin}
      />

      {/* Main Content Area */}
      <main className="flex-1 py-8 sm:py-12 px-4 sm:px-6">
        {viewingFileId ? (
          /* SHARE / DIRECT DOWNLOAD LANDING PAGE */
          <ShareLandingPage
            fileId={viewingFileId}
            onGoBack={closeSharePage}
            autoDownload={autoDownload}
          />
        ) : activeTab === 'upload' ? (
          /* UPLOAD VIEW */
          <div className="space-y-10">
            {/* Hero Header */}
            <div className="max-w-3xl mx-auto text-center space-y-3">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-700 text-xs font-bold shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>منصة رفع الملفات السريعة بالروابط المباشرة</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
                ارفع أي ملف واحصل على{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-sky-500">
                  رابط تنزيل مباشر
                </span>{' '}
                فوراً
              </h1>

              <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed">
                ألصق الرابط المباشر في أي متصفح ليبدأ التنزيل تلقائياً بدون انتظار أو إعلانات مزعجة. يدعم رفع حتى 40 ميجابايت للمرة الواحدة وحفظ سحابي في قاعدة البيانات.
              </p>

              {/* Feature Pill Highlights */}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-xs font-bold text-slate-600">
                <span className="flex items-center gap-1.5 bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full border border-indigo-200/80 shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                  دعم حتى 40 ميجابايت
                </span>
                <span className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                  رابط مباشر بدون وسيط
                </span>
                <span className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                  تسجيل الدخول بـ Google
                </span>
                <span className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                  مؤشر تقدم فوري
                </span>
              </div>
            </div>

            {/* Upload Zone */}
            <UploadZone
              user={user}
              onUploadSuccess={handleUploadSuccess}
              onOpenSharePage={openSharePage}
            />
          </div>
        ) : (
          /* MY FILES DASHBOARD */
          <MyFiles
            user={user}
            files={userFiles}
            onFileDeleted={handleFileDeleted}
            onGoToUpload={() => {
              closeSharePage();
              setActiveTab('upload');
            }}
            onOpenSharePage={openSharePage}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white/80 py-8 px-4 text-center">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2 font-bold text-slate-700">
            <Cloud className="w-4 h-4 text-indigo-600" />
            <span>سحاب — منصة رفع ومشاركة الملفات برابط تنزيل مباشر</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>سرعة فائقة</span>
            <span>•</span>
            <span>تنزيل مباشر بدون إعلانات</span>
            <span>•</span>
            <span>حفظ سحابي آمن</span>
          </div>

          <p className="text-slate-400">
            جميع الحقوق محفوظة © {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}
