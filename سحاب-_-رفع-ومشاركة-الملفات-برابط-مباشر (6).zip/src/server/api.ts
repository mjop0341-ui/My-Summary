import express from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const app = express();

// Ensure uploads directory exists
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const METADATA_FILE = path.join(UPLOADS_DIR, 'metadata.json');

interface LocalFileRecord {
  id: string;
  name: string;
  storedFilename: string;
  size: number;
  mimeType: string;
  extension: string;
  downloadsCount: number;
  userId: string | null;
  userEmail: string | null;
  userName: string | null;
  createdAt: string;
  isPublic: boolean;
}

function readMetadata(): Record<string, LocalFileRecord> {
  try {
    if (fs.existsSync(METADATA_FILE)) {
      const data = fs.readFileSync(METADATA_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading metadata.json:', err);
  }
  return {};
}

function writeMetadata(data: Record<string, LocalFileRecord>) {
  try {
    fs.writeFileSync(METADATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing metadata.json:', err);
  }
}

// Helpers for unified response in both Express and raw Node Connect middleware
function sendJson(res: any, status: number, data: any) {
  if (typeof res.status === 'function' && typeof res.json === 'function') {
    return res.status(status).json(data);
  }
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

function sendHtml(res: any, status: number, html: string) {
  if (typeof res.status === 'function' && typeof res.send === 'function') {
    return res.status(status).send(html);
  }
  res.statusCode = status;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(html);
}

// Multer disk storage
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const fileId = crypto.randomBytes(6).toString('hex');
    const safeExt = path.extname(file.originalname).slice(1).toLowerCase() || 'bin';
    const storedName = `${fileId}.${safeExt}`;
    cb(null, storedName);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 1024 * 1024 * 1024, // 1GB
  },
});

function getExt(filename: string): string {
  const ext = path.extname(filename).slice(1).toLowerCase();
  return ext || 'bin';
}

// 1. Upload endpoint
app.post('/api/upload', upload.single('file'), (req: any, res: any) => {
  try {
    if (!req.file) {
      return sendJson(res, 400, { error: 'لم يتم استلام أي ملف للرفع' });
    }

    const file = req.file;
    const fileId = path.parse(file.filename).name;
    const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
    const ext = getExt(originalName);

    const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
    const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000';
    const baseUrl = `${protocol}://${host}`;

    const userId = (req.body?.userId as string) || null;
    const userEmail = (req.body?.userEmail as string) || null;
    const userName = (req.body?.userName as string) || null;

    const fileRecord: LocalFileRecord = {
      id: fileId,
      name: originalName,
      storedFilename: file.filename,
      size: file.size,
      mimeType: file.mimetype || 'application/octet-stream',
      extension: ext,
      downloadsCount: 0,
      userId,
      userEmail,
      userName,
      createdAt: new Date().toISOString(),
      isPublic: true,
    };

    const metadata = readMetadata();
    metadata[fileId] = fileRecord;
    writeMetadata(metadata);

    const directUrl = `${baseUrl}/d/${fileId}`;
    const shareUrl = `${baseUrl}/#file=${fileId}`;
    const previewUrl = `${baseUrl}/api/preview/${fileId}`;

    return sendJson(res, 200, {
      success: true,
      file: {
        ...fileRecord,
        directUrl,
        shareUrl,
        previewUrl,
      },
    });
  } catch (err: any) {
    console.error('Upload error:', err);
    return sendJson(res, 500, { error: err.message || 'فشل رفع الملف' });
  }
});

// 2. Direct download route: /d/:id or /api/download/:id
const handleDownload = (req: any, res: any) => {
  // Extract id either from req.params.id or url matching
  const fileId = req.params?.id || req.url.split('/').pop()?.split('?')[0];

  if (!fileId) {
    return sendJson(res, 400, { error: 'معرف الملف مفقود' });
  }

  const metadata = readMetadata();
  const fileRecord = metadata[fileId];

  const localUploadsDir = UPLOADS_DIR;
  const filePath = fileRecord ? path.join(localUploadsDir, fileRecord.storedFilename) : null;

  if (fileRecord && filePath && fs.existsSync(filePath)) {
    // Increment downloads count
    fileRecord.downloadsCount = (fileRecord.downloadsCount || 0) + 1;
    metadata[fileId] = fileRecord;
    writeMetadata(metadata);

    // Precise MIME type handling for APK and others
    let mimeType = fileRecord.mimeType || 'application/octet-stream';
    if (fileRecord.extension === 'apk' || fileRecord.name.endsWith('.apk')) {
      mimeType = 'application/vnd.android.package-archive';
    }

    // Set response headers for immediate download in ANY browser without intermediary pages
    const safeAsciiName = fileRecord.name.replace(/[^\x20-\x7E]/g, '_');
    const utf8Name = encodeURIComponent(fileRecord.name);
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${safeAsciiName}"; filename*=UTF-8''${utf8Name}`
    );
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Content-Length', fileRecord.size);
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=31536000');

    const readStream = fs.createReadStream(filePath);
    return readStream.pipe(res);
  }

  // Not on local disk: Fetch from Firestore REST API
  (async () => {
    try {
      const fbConfig = {
        projectId: "gen-lang-client-0896569783",
        firestoreDatabaseId: "ai-studio-f0d94df3-b02e-4b72-b3b2-aa8c84a5f0fb",
        apiKey: "AIzaSyBj7NGzQEtsM5-qPKqsi3WqzcGtnqCfPE0",
      };
      const firestoreUrl = `https://firestore.googleapis.com/v1/projects/${fbConfig.projectId}/databases/${fbConfig.firestoreDatabaseId}/documents/files/${fileId}?key=${fbConfig.apiKey}`;
      const firestoreRes = await fetch(firestoreUrl);

      if (!firestoreRes.ok) {
        return sendHtml(
          res,
          404,
          `
          <html dir="rtl" style="font-family: system-ui, sans-serif; text-align: center; padding: 50px; background: #f8fafc;">
            <h2 style="color: #1e293b;">الملف غير موجود أو تم حذفه</h2>
            <p style="color: #64748b;">تأكد من صحة الرابط أو قم بالرجوع للصفحة الرئيسية.</p>
            <a href="/" style="display: inline-block; padding: 10px 20px; background: #4f46e5; color: white; border-radius: 8px; text-decoration: none; margin-top: 15px;">الذهاب للرئيسية</a>
          </html>
        `
        );
      }

      const docData: any = await firestoreRes.json();
      const fields = docData.fields || {};
      const fileName = fields.name?.stringValue || `file_${fileId}.bin`;
      const mimeType = fields.mimeType?.stringValue || 'application/octet-stream';
      const storageUrl = fields.storageUrl?.stringValue;
      const base64Data = fields.base64Data?.stringValue;
      const chunksCount = fields.chunksCount?.integerValue ? parseInt(fields.chunksCount.integerValue, 10) : 0;

      if (storageUrl) {
        res.writeHead(302, { Location: storageUrl });
        return res.end();
      }

      if (base64Data) {
        const cleanBase64 = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
        const buffer = Buffer.from(cleanBase64, 'base64');
        const encodedName = encodeURIComponent(fileName);

        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${encodedName}"; filename*=UTF-8''${encodedName}`
        );
        res.setHeader('Content-Type', mimeType);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Cache-Control', 'public, max-age=31536000');
        return res.end(buffer);
      }

      if (chunksCount > 0) {
        const chunks: { index: number; data: string }[] = [];
        const chunksUrl = `https://firestore.googleapis.com/v1/projects/${fbConfig.projectId}/databases/${fbConfig.firestoreDatabaseId}/documents/files/${fileId}/chunks?key=${fbConfig.apiKey}&pageSize=100`;
        const chunksRes = await fetch(chunksUrl);
        if (chunksRes.ok) {
          const chunksData: any = await chunksRes.json();
          for (const doc of chunksData.documents || []) {
            const cFields = doc.fields || {};
            const cIdx = parseInt(cFields.chunkIndex?.integerValue || '0', 10);
            const cData = cFields.data?.stringValue || '';
            chunks.push({ index: cIdx, data: cData });
          }
          chunks.sort((a, b) => a.index - b.index);
          const buffers = chunks.map((c) => {
            const clean = c.data.includes(',') ? c.data.split(',')[1] : c.data;
            return Buffer.from(clean, 'base64');
          });
          const buffer = Buffer.concat(buffers);
          const encodedName = encodeURIComponent(fileName);

          res.setHeader(
            'Content-Disposition',
            `attachment; filename="${encodedName}"; filename*=UTF-8''${encodedName}`
          );
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Content-Length', buffer.length);
          res.setHeader('Cache-Control', 'public, max-age=31536000');
          return res.end(buffer);
        }
      }

      return sendHtml(res, 404, 'الملف غير موجود');
    } catch (e: any) {
      console.error('Download error:', e);
      return sendHtml(res, 500, 'خطأ في تحميل الملف');
    }
  })();
};

app.get('/d/:id', handleDownload);
app.get('/api/download/:id', handleDownload);

// 3. Preview route
app.get('/api/preview/:id', (req: any, res: any) => {
  const fileId = req.params?.id || req.url.split('/').pop()?.split('?')[0];
  const metadata = readMetadata();
  const fileRecord = metadata[fileId];

  if (!fileRecord) {
    return sendHtml(res, 404, 'Not Found');
  }

  const filePath = path.join(UPLOADS_DIR, fileRecord.storedFilename);
  if (!fs.existsSync(filePath)) {
    return sendHtml(res, 404, 'Not Found');
  }

  const encodedFilename = encodeURIComponent(fileRecord.name);
  res.setHeader('Content-Disposition', `inline; filename="${encodedFilename}"`);
  res.setHeader('Content-Type', fileRecord.mimeType || 'application/octet-stream');
  res.setHeader('Content-Length', fileRecord.size);

  const readStream = fs.createReadStream(filePath);
  readStream.pipe(res);
});

// 4. File metadata endpoint: /api/files/:id
app.get('/api/files/:id', (req: any, res: any) => {
  const fileId = req.params?.id;
  const metadata = readMetadata();
  const fileRecord = metadata[fileId];

  if (!fileRecord) {
    return sendJson(res, 404, { error: 'الملف غير موجود' });
  }

  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000';
  const baseUrl = `${protocol}://${host}`;

  return sendJson(res, 200, {
    ...fileRecord,
    directUrl: `${baseUrl}/d/${fileRecord.id}`,
    shareUrl: `${baseUrl}/#file=${fileRecord.id}`,
    previewUrl: `${baseUrl}/api/preview/${fileRecord.id}`,
  });
});

// 5. Files list: /api/files
app.get('/api/files', (req: any, res: any) => {
  const userId = req.query?.userId as string | undefined;
  const metadata = readMetadata();
  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000';
  const baseUrl = `${protocol}://${host}`;

  let list = Object.values(metadata);
  if (userId) {
    list = list.filter((f) => f.userId === userId);
  }

  // Sort by newest first
  list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const result = list.map((f) => ({
    ...f,
    directUrl: `${baseUrl}/d/${f.id}`,
    shareUrl: `${baseUrl}/#file=${f.id}`,
    previewUrl: `${baseUrl}/api/preview/${f.id}`,
  }));

  return sendJson(res, 200, result);
});

// 6. Delete file: /api/files/:id
app.delete('/api/files/:id', (req: any, res: any) => {
  const fileId = req.params?.id;
  const metadata = readMetadata();
  const fileRecord = metadata[fileId];

  if (!fileRecord) {
    return sendJson(res, 404, { error: 'الملف غير موجود' });
  }

  const filePath = path.join(UPLOADS_DIR, fileRecord.storedFilename);
  if (fs.existsSync(filePath)) {
    try {
      fs.unlinkSync(filePath);
    } catch (e) {
      console.error('Error removing file:', e);
    }
  }

  delete metadata[fileId];
  writeMetadata(metadata);

  return sendJson(res, 200, { success: true, message: 'تم حذف الملف بنجاح' });
});

export default app;
