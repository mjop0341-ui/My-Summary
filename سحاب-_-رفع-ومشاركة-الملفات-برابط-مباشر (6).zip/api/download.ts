import fs from 'fs';
import path from 'path';

// Firebase configuration for serverless functions
const firebaseConfig = {
  projectId: "gen-lang-client-0896569783",
  firestoreDatabaseId: "ai-studio-f0d94df3-b02e-4b72-b3b2-aa8c84a5f0fb",
  apiKey: "AIzaSyBj7NGzQEtsM5-qPKqsi3WqzcGtnqCfPE0",
};

export default async function handler(req: any, res: any) {
  try {
    // Extract fileId from query or url path
    const fileId = req.query?.id || req.url?.split('/').pop()?.split('?')[0];

    if (!fileId) {
      res.statusCode = 400;
      return res.end('Missing file ID');
    }

    // 1. Check local disk or /tmp (Vercel serverless environment)
    const possibleDirs = [
      path.resolve(process.cwd(), 'uploads'),
      '/tmp/uploads',
    ];

    for (const localUploadsDir of possibleDirs) {
      const metadataFile = path.join(localUploadsDir, 'metadata.json');
      if (fs.existsSync(metadataFile)) {
        try {
          const metadata = JSON.parse(fs.readFileSync(metadataFile, 'utf-8'));
          const fileRecord = metadata[fileId];
          if (fileRecord) {
            const filePath = path.join(localUploadsDir, fileRecord.storedFilename);
            if (fs.existsSync(filePath)) {
              let mimeType = fileRecord.mimeType || 'application/octet-stream';
              if (fileRecord.extension === 'apk' || fileRecord.name.endsWith('.apk')) {
                mimeType = 'application/vnd.android.package-archive';
              }
              const safeAsciiName = fileRecord.name.replace(/[^\x20-\x7E]/g, '_');
              const utf8Name = encodeURIComponent(fileRecord.name);
              res.setHeader(
                'Content-Disposition',
                `attachment; filename="${safeAsciiName}"; filename*=UTF-8''${utf8Name}`
              );
              res.setHeader('Content-Type', mimeType);
              res.setHeader('Content-Length', fileRecord.size);
              res.setHeader('Accept-Ranges', 'bytes');
              res.setHeader('Cache-Control', 'public, max-age=31536000');
              return fs.createReadStream(filePath).pipe(res);
            }
          }
        } catch (e) {
          console.warn('Local disk read error:', e);
        }
      }
    }

    // 2. Fetch from Firestore REST API (Works 100% in Vercel Serverless Functions)
    const firestoreUrl = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/files/${fileId}?key=${firebaseConfig.apiKey}`;
    const firestoreRes = await fetch(firestoreUrl);

    if (!firestoreRes.ok) {
      res.statusCode = 404;
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.end(`
        <html dir="rtl" style="font-family: system-ui, sans-serif; text-align: center; padding: 50px;">
          <h2>الملف غير موجود أو تم حذفه</h2>
          <p>تأكد من صحة الرابط المباشر.</p>
          <a href="/" style="display: inline-block; padding: 10px 20px; background: #4f46e5; color: white; border-radius: 8px; text-decoration: none;">الصفحة الرئيسية</a>
        </html>
      `);
    }

    const docData: any = await firestoreRes.json();
    const fields = docData.fields || {};

    const fileName = fields.name?.stringValue || `file_${fileId}.bin`;
    const mimeType = fields.mimeType?.stringValue || 'application/octet-stream';
    const storageUrl = fields.storageUrl?.stringValue;
    const base64Data = fields.base64Data?.stringValue;
    const chunksCount = fields.chunksCount?.integerValue ? parseInt(fields.chunksCount.integerValue, 10) : 0;

    // A. If Firebase Storage URL available, redirect immediately to Google Cloud Storage CDN
    if (storageUrl) {
      res.writeHead(302, { Location: storageUrl });
      return res.end();
    }

    // B. If direct base64 data available
    if (base64Data) {
      const cleanBase64 = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
      const buffer = Buffer.from(cleanBase64, 'base64');
      const encodedName = encodeURIComponent(fileName);

      // THESE HEADERS FORCE THE BROWSER TO DOWNLOAD DIRECTLY WITHOUT RENDERING ANY PAGE
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${encodedName}"; filename*=UTF-8''${encodedName}`
      );
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Length', buffer.length);
      res.setHeader('Cache-Control', 'public, max-age=31536000');
      return res.end(buffer);
    }

    // C. If chunks available in Firestore
    if (chunksCount > 0) {
      const chunks: { index: number; data: string }[] = [];
      const chunksUrl = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/files/${fileId}/chunks?key=${firebaseConfig.apiKey}&pageSize=100`;
      const chunksRes = await fetch(chunksUrl);
      if (chunksRes.ok) {
        const chunksData: any = await chunksRes.json();
        for (const doc of chunksData.documents || []) {
          const cFields = doc.fields || {};
          const cIdx = parseInt(cFields.chunkIndex?.integerValue || '0', 10);
          const cData = cFields.data?.stringValue || '';
          chunks.push({ index: cIdx, data: cData });
        }
        const buffers = chunks.map((c) => {
          const clean = c.data.includes(',') ? c.data.split(',')[1] : c.data;
          return Buffer.from(clean, 'base64');
        });
        const buffer = Buffer.concat(buffers);
        const encodedName = encodeURIComponent(fileName);

        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${encodedName}"; filename*=UTF-8''${encodedName}`
        );
        res.setHeader('Content-Type', mimeType);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Cache-Control', 'public, max-age=31536000');
        return res.end(buffer);
      }
    }

    // Fallback if no binary data found
    res.statusCode = 404;
    return res.end('File data not found');
  } catch (err: any) {
    console.error('Download serverless error:', err);
    res.statusCode = 500;
    return res.end('Server error downloading file');
  }
}
