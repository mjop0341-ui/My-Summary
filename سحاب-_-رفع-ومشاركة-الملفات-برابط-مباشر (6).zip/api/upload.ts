import multer from 'multer';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// Disable default Vercel body parser to allow raw multipart stream
export const config = {
  api: {
    bodyParser: false,
  },
};

const UPLOADS_DIR = process.env.VERCEL ? '/tmp/uploads' : path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const METADATA_FILE = path.join(UPLOADS_DIR, 'metadata.json');

function readMetadata(): Record<string, any> {
  try {
    if (fs.existsSync(METADATA_FILE)) {
      return JSON.parse(fs.readFileSync(METADATA_FILE, 'utf-8'));
    }
  } catch (err) {
    console.error('Error reading metadata:', err);
  }
  return {};
}

function writeMetadata(data: Record<string, any>) {
  try {
    fs.writeFileSync(METADATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing metadata:', err);
  }
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const fileId = crypto.randomBytes(6).toString('hex');
    const safeExt = path.extname(file.originalname).slice(1).toLowerCase() || 'bin';
    cb(null, `${fileId}.${safeExt}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 50 * 1024 * 1024,
  },
});

function runMiddleware(req: any, res: any, fn: any) {
  return new Promise((resolve, reject) => {
    fn(req, res, (result: any) => {
      if (result instanceof Error) {
        return reject(result);
      }
      return resolve(result);
    });
  });
}

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    res.statusCode = 405;
    return res.end(JSON.stringify({ error: 'Method Not Allowed' }));
  }

  try {
    await runMiddleware(req, res, upload.single('file'));

    if (!req.file) {
      res.statusCode = 400;
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify({ error: 'لم يتم استلام أي ملف' }));
    }

    const file = req.file;
    const fileId = path.parse(file.filename).name;
    const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
    const ext = path.extname(originalName).slice(1).toLowerCase() || 'bin';

    const protocol = req.headers['x-forwarded-proto'] || 'https';
    const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000';
    const baseUrl = `${protocol}://${host}`;

    const userId = (req.body?.userId as string) || null;
    const userEmail = (req.body?.userEmail as string) || null;
    const userName = (req.body?.userName as string) || null;

    const fileRecord = {
      id: fileId,
      name: originalName,
      storedFilename: file.filename,
      size: file.size,
      mimeType: file.mimetype || 'application/octet-stream',
      extension: ext,
      downloadsCount: 0,
      userId,
      userEmail,
      userName,
      createdAt: new Date().toISOString(),
      isPublic: true,
      directUrl: `${baseUrl}/d/${fileId}`,
      shareUrl: `${baseUrl}/#file=${fileId}`,
      previewUrl: `${baseUrl}/api/preview/${fileId}`,
    };

    const metadata = readMetadata();
    metadata[fileId] = fileRecord;
    writeMetadata(metadata);

    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    return res.end(
      JSON.stringify({
        success: true,
        file: fileRecord,
      })
    );
  } catch (err: any) {
    console.error('Serverless upload error:', err);
    res.statusCode = 500;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify({ error: err.message || 'فشل رفع الملف' }));
  }
}
